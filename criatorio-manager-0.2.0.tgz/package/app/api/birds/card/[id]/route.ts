import { requireUser } from "@/lib/auth";

const esc = (x:any) => String(x ?? "—").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;", "'":"&#39;"}[c]!));
const sexLabel = (s:string) => ({macho:"M", femea:"F", indeterminado:"—"}[s] || s || "—");

async function getAncestor(supabase:any, id:string|null, userId:string){
  if(!id) return null;
  const {data}=await supabase.from("birds").select("id,name,sex,ring_number,father_id,mother_id,genetic_line").eq("id",id).eq("user_id",userId).maybeSingle();
  return data || null;
}

export async function GET(request:Request,{params}:{params:Promise<{id:string}>}){
  const {id}=await params;
  const {supabase,user}=await requireUser();
  const preview=new URL(request.url).searchParams.get("preview")==="1";

  const {data:profile}=await supabase.from("profiles")
    .select("plan,full_name,criatorio_name,criatorio_logo_path,phone,city,state,ctf_number")
    .eq("id",user.id).maybeSingle();
  if(!profile) return new Response("Perfil não encontrado",{status:404});
  if(profile.plan==="free"&&!preview) return new Response("A impressão do cartão está disponível somente nos planos pagos.",{status:403});

  const {data:b}=await supabase.from("birds")
    .select("id,name,sex,birth_date,status,ring_number,ibama_registration_number,ibama_record_type,genetic_line,genetics,father_id,mother_id,notes,species:species_id(common_name,scientific_name)")
    .eq("id",id).eq("user_id",user.id).maybeSingle();
  if(!b) return new Response("Ave não encontrada",{status:404});

  const father=await getAncestor(supabase,b.father_id,user.id);
  const mother=await getAncestor(supabase,b.mother_id,user.id);
  const [ff,fm,mf,mm]=await Promise.all([
    getAncestor(supabase,father?.father_id||null,user.id),
    getAncestor(supabase,father?.mother_id||null,user.id),
    getAncestor(supabase,mother?.father_id||null,user.id),
    getAncestor(supabase,mother?.mother_id||null,user.id),
  ]);
  const {data:children}=await supabase.from("birds").select("name,sex,ring_number").eq("user_id",user.id).or(`father_id.eq.${id},mother_id.eq.${id}`).order("name").limit(8);

  let logoUrl="";
  if(profile.criatorio_logo_path){
    const {data}=await supabase.storage.from("criatorio-brand").createSignedUrl(profile.criatorio_logo_path,3600);
    logoUrl=data?.signedUrl||"";
  }

  const genetics=Object.entries((b.genetics||{}) as Record<string,unknown>).map(([k,v])=>`${k}: ${v}`).join(" · ");
  const status={ativo:"Ativo",falecido:"Falecido",transferido:"Transferido",arquivado:"Arquivado"}[b.status as string]||b.status;
  const brand=esc(profile.criatorio_name||"Meu Criatório");
  const responsible=esc(profile.full_name||"—");
  const logo=(alt:string)=>logoUrl?`<img class="logo" src="${esc(logoUrl)}" alt="${alt}">`:``;
  const node=(label:string,x:any)=>`<div class="node"><span>${esc(label)}</span><strong>${esc(x?.name||"Não informado")}</strong><small>${x?.ring_number?`Anilha ${esc(x.ring_number)}`:"—"}</small></div>`;
  const childRows=(children||[]).map((c:any)=>`<span class="child-chip">${esc(c.name)}${c.ring_number?` · ${esc(c.ring_number)}`:""}</span>`).join("")||`<span class="muted">Nenhum descendente cadastrado.</span>`;

  const html=`<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Cartão de gaiola — ${esc(b.name)}</title>
<style>
*{box-sizing:border-box}html,body{margin:0;padding:0;background:#edf6f1;color:#17372b;font-family:Arial,Helvetica,sans-serif}.toolbar{max-width:980px;margin:18px auto;text-align:center}.toolbar button{border:0;background:#2f9a70;color:#fff;padding:11px 18px;border-radius:10px;font-weight:800;cursor:pointer}.preview{margin-top:8px;color:#60766c;font-size:12px}.sheet{width:100%;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px}.card{width:92mm;height:62mm;background:#fff;border:1px solid #b9dfcf;border-radius:5mm;position:relative;overflow:hidden;box-shadow:0 10px 30px #1e6b4a16}.card:before{content:"";position:absolute;inset:0;border-top:4px solid #43b684;pointer-events:none}.brandbar{height:13mm;display:flex;align-items:center;gap:3mm;padding:3mm 4mm 2mm;border-bottom:1px solid #dcefe7}.logo{width:9mm;height:9mm;object-fit:contain;border-radius:2mm;background:#f5fbf8}.brandname{font-size:4.2mm;font-weight:900;line-height:1.05;color:#176043}.responsible{font-size:2.2mm;color:#70867d;margin-top:1mm}.content{padding:3mm 4mm}.birdname{font-size:6mm;font-weight:900;line-height:1;color:#17372b}.species{font-size:2.4mm;color:#638078;margin-top:1mm}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1.5mm;margin-top:3mm}.field{border:1px solid #c7e3d7;border-radius:1.8mm;padding:1.4mm 1.6mm;min-height:8.5mm}.field.wide{grid-column:span 2}.label{font-size:1.8mm;color:#628078;text-transform:uppercase;font-weight:800}.value{font-size:2.9mm;font-weight:800;color:#1f5f47;margin-top:.8mm;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.footerline{position:absolute;bottom:2.5mm;left:4mm;right:4mm;font-size:1.8mm;color:#7a8f87;display:flex;justify-content:space-between}.back .brandbar{border-bottom:0}.back-title{font-size:4mm;font-weight:900;color:#176043}.back-sub{font-size:2mm;color:#70867d}.tree{position:relative;margin-top:2mm;height:30mm}.node{position:absolute;width:28mm;min-height:7mm;padding:1mm;border:1px solid #b9d9cd;border-radius:1.6mm;background:#fff;box-shadow:0 1px 3px #17372b0c}.node span{display:block;font-size:1.6mm;color:#7b9088;text-transform:uppercase}.node strong{display:block;font-size:2.1mm;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.node small{display:block;font-size:1.55mm;color:#71867e;margin-top:.4mm}.gp1{left:0;top:0}.gp2{left:0;top:10mm}.gp3{right:0;top:0}.gp4{right:0;top:10mm}.parent1{left:25mm;top:5mm}.parent2{right:25mm;top:5mm}.mainnode{left:32mm;bottom:0;width:28mm;border-color:#43b684;background:#f2fbf7}.line{position:absolute;background:#9fcbb9;height:.35mm}.l1{left:24mm;top:4mm;width:5mm;transform:rotate(20deg)}.l2{left:24mm;top:13mm;width:5mm;transform:rotate(-20deg)}.l3{right:24mm;top:4mm;width:5mm;transform:rotate(-20deg)}.l4{right:24mm;top:13mm;width:5mm;transform:rotate(20deg)}.l5{left:39mm;top:14mm;width:14mm;transform:rotate(90deg)}.genetic{position:absolute;left:4mm;right:4mm;bottom:2.8mm;border-top:1px solid #dcefe7;padding-top:1.5mm;font-size:1.8mm;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.genetic b{color:#4f7468}.desc{position:absolute;right:4mm;bottom:2.8mm;max-width:44mm;text-align:right;font-size:1.7mm;color:#71867e}.child-chip{display:inline-block;border:1px solid #d5e9e1;border-radius:1.2mm;padding:.7mm 1mm;margin:0 .7mm .7mm 0;font-size:1.65mm}.muted{color:#81928c}.back .content{padding-top:1mm}.back .brandbar{height:11mm;padding-bottom:1mm}.back .logo{width:8mm;height:8mm}.back .brandname{font-size:3.5mm}
@media print{html,body{background:#fff}.toolbar{display:none}.sheet{height:100vh;min-height:0;padding:0;page-break-after:always}.sheet:last-of-type{page-break-after:auto}.card{box-shadow:none}.preview{display:none}}@page{size:A4;margin:0}
@media(max-width:600px){.sheet{padding:12px}.card{transform-origin:center;max-width:92mm}.toolbar{padding:0 12px}}
</style></head><body>
<div class="toolbar"><button onclick="window.print()">🖨 Imprimir cartão frente e verso</button>${profile.plan==="free"?`<div class="preview">Pré-visualização liberada no Grátis. A impressão fica disponível nos planos pagos.</div>`:""}</div>
<div class="sheet"><div class="card front">
<div class="brandbar">${logo("Logo do criatório")}<div><div class="brandname">${brand}</div><div class="responsible">Responsável: ${responsible}</div></div></div>
<div class="content"><div class="birdname">${esc(b.name)}</div><div class="species">${esc(b.species?.common_name||"Espécie não informada")} · <i>${esc(b.species?.scientific_name||"")}</i></div>
<div class="grid"><div class="field"><div class="label">Nome da ave</div><div class="value">${esc(b.name)}</div></div><div class="field"><div class="label">Proprietário</div><div class="value">${responsible}</div></div><div class="field"><div class="label">CTF</div><div class="value">${esc(profile.ctf_number||"Não informado")}</div></div>
<div class="field"><div class="label">Nascimento</div><div class="value">${esc(b.birth_date||"—")}</div></div><div class="field"><div class="label">Sexo</div><div class="value">${esc(sexLabel(b.sex))}</div></div><div class="field"><div class="label">Anilha</div><div class="value">${esc(b.ring_number||"—")}</div></div>
<div class="field wide"><div class="label">Espécie</div><div class="value">${esc(b.species?.common_name||"—")}</div></div><div class="field"><div class="label">Registro</div><div class="value">${esc(b.ibama_registration_number||"—")}</div></div></div></div>
<div class="footerline"><span>${esc(status)}</span><span>${esc(b.ibama_record_type||"Registro não informado")}</span></div></div></div>
<div class="sheet"><div class="card back">
<div class="brandbar">${logo("Logo do criatório")}<div><div class="brandname">${brand}</div><div class="responsible">Ficha de identificação · ${esc(b.name)}</div></div></div>
<div class="content"><div class="back-title">Genealogia da ave</div><div class="back-sub">Pais e avós cadastrados no plantel · verso do cartão de gaiola</div>
<div class="tree">${node("Avô paterno",ff)}${node("Avó paterna",fm)}${node("Pai",father)}${node("Avô materno",mf)}${node("Avó materna",mm)}${node("Mãe",mother)}${node("Ave",b)}<div class="line l1"></div><div class="line l2"></div><div class="line l3"></div><div class="line l4"></div><div class="line l5"></div></div>
<div style="font-size:1.75mm;color:#70867d;margin-top:-1mm"><b>Filhos:</b> ${childRows}</div>
</div><div class="genetic"><b>Genética:</b> ${esc(genetics||b.genetic_line||"Não informada")} · <b>Matriz:</b> ${b.breeder_matrix?"Sim":"Não"}</div><div class="desc">${logoUrl?"Identidade do criatório aplicada frente e verso · ":""}CTF: ${esc(profile.ctf_number||"Não informado")}</div>
</div></div></body></html>`;

  if(profile.plan==="free" && !preview) return new Response("A impressão do cartão está disponível somente nos planos pagos.",{status:403});
  return new Response(html,{headers:{"content-type":"text/html;charset=utf-8"}});
}
