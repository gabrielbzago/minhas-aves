import {NextResponse} from "next/server"; import {requireUser} from "@/lib/auth";
export async function GET(){const {supabase}=await requireUser();const {data,error}=await supabase.from("birds").select("*").order("created_at",{ascending:false});return NextResponse.json({data,error});}
export async function POST(request:Request){const {supabase}=await requireUser();const body=await request.json();const {data,error}=await supabase.from("birds").insert(body).select().single();return NextResponse.json({data,error},{status:error?400:201});}
