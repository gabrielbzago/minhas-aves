import {NextResponse} from "next/server";
import {requireUser} from "@/lib/auth";
import {getStripe} from "@/lib/stripe";

export async function GET(request:Request){
  const {user}=await requireUser();
  const plan=new URL(request.url).searchParams.get("plan");
  const priceId=plan==="amador"?process.env.STRIPE_PRICE_AMADOR:plan==="profissional"?process.env.STRIPE_PRICE_PROFISSIONAL:plan==="lenda"?process.env.STRIPE_PRICE_LENDA:null;
  if(!priceId)return NextResponse.json({error:"Plano não configurado."},{status:400});
  const stripe=getStripe();
  const session=await stripe.checkout.sessions.create({
    mode:"subscription",
    line_items:[{price:priceId,quantity:1}],
    customer_email:user.email||undefined,
    client_reference_id:user.id,
    metadata:{user_id:user.id,plan:plan!},
    subscription_data:{metadata:{user_id:user.id,plan:plan!}},
    success_url:`${process.env.NEXT_PUBLIC_APP_URL}/dashboard/assinatura?success=1`,
    cancel_url:`${process.env.NEXT_PUBLIC_APP_URL}/dashboard/assinatura?canceled=1`
  });
  return NextResponse.redirect(session.url!,303);
}
