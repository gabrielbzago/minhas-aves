import {NextResponse} from "next/server";
import {getStripe} from "@/lib/stripe";
import {createAdminClient} from "@/lib/supabase/admin";
import Stripe from "stripe";

function unixDate(v:number|null|undefined){return v?new Date(v*1000).toISOString():null}

export async function POST(request:Request){
 const body=await request.text(); const signature=request.headers.get("stripe-signature"); const secret=process.env.STRIPE_WEBHOOK_SECRET;
 if(!signature||!secret)return NextResponse.json({error:"Webhook não configurado."},{status:400});
 let event:Stripe.Event; try{event=getStripe().webhooks.constructEvent(body,signature,secret)}catch(e:any){return NextResponse.json({error:`Assinatura inválida: ${e.message}`},{status:400})}
 const admin=createAdminClient();
 try{
   const exists=await admin.from("subscription_events").select("id").eq("stripe_event_id",event.id).maybeSingle();
   if(exists.data)return NextResponse.json({received:true,duplicate:true});
   await admin.from("subscription_events").insert({stripe_event_id:event.id,event_type:event.type,payload:event});
   switch(event.type){
    case "checkout.session.completed":{
      const s=event.data.object as Stripe.Checkout.Session;
      const userId=s.client_reference_id||s.metadata?.user_id; const plan=s.metadata?.plan;
      if(userId&&plan){
        const subId=typeof s.subscription==="string"?s.subscription:null;
        let sub:Stripe.Subscription|null=null;
        if(subId) sub=await getStripe().subscriptions.retrieve(subId);
        const start=unixDate(sub?.current_period_start); const end=unixDate(sub?.current_period_end);
        await admin.from("profiles").update({plan,stripe_customer_id:typeof s.customer==="string"?s.customer:null,stripe_subscription_id:subId,subscription_status:sub?.status||"active",current_period_start:start,current_period_end:end,lenda_consultation_used:plan==="lenda"?false:false,lenda_consultation_used_at:null}).eq("id",userId); if(plan==="lenda"){ await admin.rpc("record_vet_subscription_history",{p_creator_id:userId,p_plan:plan,p_event_type:"checkout.session.completed",p_status:sub?.status||"active",p_subscription_id:subId,p_period_start:start,p_period_end:end,p_note:"Assinatura Lenda iniciada"}); if(subId) await admin.rpc("create_lenda_payout",{p_creator_id:userId,p_subscription_id:subId,p_period_start:start}); }
      } break;
    }
    case "customer.subscription.created":
    case "customer.subscription.updated":{
      const sub=event.data.object as Stripe.Subscription; const userId=sub.metadata?.user_id; const plan=sub.metadata?.plan;
      if(userId){
        const current=await admin.from("profiles").select("plan,current_period_start").eq("id",userId).maybeSingle();
        const nextStart=unixDate(sub.current_period_start); const periodChanged=current.data?.current_period_start!==nextStart;
        await admin.from("profiles").update({plan:plan||current.data?.plan||"free",stripe_customer_id:typeof sub.customer==="string"?sub.customer:null,stripe_subscription_id:sub.id,subscription_status:sub.status,current_period_start:nextStart,current_period_end:unixDate(sub.current_period_end),...(plan==="lenda"&&periodChanged?{lenda_consultation_used:false,lenda_consultation_used_at:null}:{})}).eq("id",userId); if(plan==="lenda"){ await admin.rpc("record_vet_subscription_history",{p_creator_id:userId,p_plan:plan,p_event_type:event.type,p_status:sub.status,p_subscription_id:sub.id,p_period_start:nextStart,p_period_end:unixDate(sub.current_period_end),p_note:periodChanged?"Período de assinatura atualizado":"Status de assinatura atualizado"}); if(event.type==="customer.subscription.updated" && periodChanged) await admin.rpc("create_lenda_payout",{p_creator_id:userId,p_subscription_id:sub.id,p_period_start:nextStart}); }
      } break;
    }
    case "customer.subscription.deleted":{
      const sub=event.data.object as Stripe.Subscription; const userId=sub.metadata?.user_id;
      if(userId){const old=await admin.from("profiles").select("plan").eq("id",userId).maybeSingle(); await admin.from("profiles").update({plan:"free",subscription_status:"canceled",stripe_subscription_id:sub.id,current_period_end:unixDate(sub.current_period_end)}).eq("id",userId); if(old.data?.plan==="lenda") await admin.rpc("record_vet_subscription_history",{p_creator_id:userId,p_plan:"lenda",p_event_type:"customer.subscription.deleted",p_status:"canceled",p_subscription_id:sub.id,p_period_start:null,p_period_end:unixDate(sub.current_period_end),p_note:"Assinatura cancelada"});}
      break;
    }
    case "charge.dispute.created":{
      const dispute=event.data.object as Stripe.Dispute; const chargeId=typeof dispute.charge==="string"?dispute.charge:null;
      if(chargeId){const charge=await getStripe().charges.retrieve(chargeId);const customer=typeof charge.customer==="string"?charge.customer:null;if(customer){const prof=await admin.from("profiles").select("id,plan").eq("stripe_customer_id",customer).maybeSingle();if(prof.data?.plan==="lenda"){await admin.from("profiles").update({subscription_status:"chargeback"}).eq("id",prof.data.id);await admin.from("vet_payouts").update({status:"cancelled",note:"Repasse cancelado por chargeback/disputa de pagamento."}).eq("creator_id",prof.data.id).eq("status","pending");await admin.rpc("record_vet_subscription_history",{p_creator_id:prof.data.id,p_plan:"lenda",p_event_type:"charge.dispute.created",p_status:"chargeback",p_subscription_id:null,p_period_start:null,p_period_end:null,p_note:"Chargeback/disputa registrada; repasse pendente cancelado."});}}}
      break;
    }
    case "invoice.payment_failed":{
      const invoice=event.data.object as Stripe.Invoice; const customer=typeof invoice.customer==="string"?invoice.customer:null;
      if(customer)await admin.from("profiles").update({subscription_status:"past_due"}).eq("stripe_customer_id",customer);
      break;
    }
   }
 }catch(e){console.error("Stripe webhook DB error",e);return NextResponse.json({error:"Erro interno do webhook."},{status:500})}
 return NextResponse.json({received:true});
}
