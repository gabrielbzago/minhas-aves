import Link from "next/link";
import { notFound } from "next/navigation";
import { requireUser } from "@/lib/auth";

async function getBird(supabase:any,id:string){const {data}=await supabase.from("birds").select("id,name,sex,ring_number,father_id,mother_id,genetic_line,species:species_id(common_name,scientific_name)").eq("id",id).maybeSingle();return data;}
function TreeCard({b,label,main}:{b:any,label:string,main?:boolean}){return <div className={`tree-card ${main?"main":""}`}><small style={{color:"var(--muted)"}}>{label}</small>{b?<><h3 style={{margin:"8px 0 4px"}}>{b.name}</h3><div style={{fontSize:11,color:"var(--muted)"}}>{b.ring_number||"Sem anilha"}</div>{b.genetic_line&&<div style={{fontSize:10,color:"var(--primary-dark)",marginTop:6}}>{b.genetic_line}</div>}<Link href={`/dashboard/plantel/${b.id}`} style={{display:"inline-block",marginTop:9,color:"var(--primary-dark)",fontSize:11,fontWeight:700}}>Abrir ficha</Link></>:<p style={{fontSize:12,color:"var(--muted)"}}>Não informado</p>}</div>}

export default async function Genealogy({params}:{params:Promise<{id:string}>}){
 const {id}=await params; const {supabase,user}=await requireUser(); const {data:profile}=await supabase.from("profiles").select("plan").eq("id",user.id).maybeSingle(); const isPaid=profile?.plan && profile.plan!=="free"; const root=await getBird(supabase,id); if(!root)notFound();
 const father=root.father_id?await getBird(supabase,root.father_id):null; const mother=root.mother_id?await getBird(supabase,root.mother_id):null;
 const [ff,fm,mf,mm]=await Promise.all([father?.father_id?getBird(supabase,father.father_id):null,father?.mother_id?getBird(supabase,father.mother_id):null,mother?.father_id?getBird(supabase,mother.father_id):null,mother?.mother_id?getBird(supabase,mother.mother_id):null]);
 const {data:children}=await supabase.from("birds").select("id,name,sex,ring_number").or(`father_id.eq.${id},mother_id.eq.${id}`).order("name");
 return <main className="content"><div className="page-title"><div><h1>Genealogia</h1><p>Árvore de {root.name} · {root.species?.common_name||""}</p></div><div className="actions" style={{margin:0}}><Link className="btn btn-ghost" href={`/dashboard/plantel/${id}`}>Voltar à ficha</Link>{isPaid?<><a className="btn btn-soft" href={`/api/print/genealogia/${id}`} target="_blank">🖨 Imprimir genealogia</a><a className="btn btn-primary" href={`/api/birds/card/${id}`} target="_blank">Imprimir cartão</a></>:<span className="btn btn-soft" title="Disponível nos planos pagos">🔒 Impressão · plano pago</span>}</div></div>
  <div className="genealogy"><div className="card"><h3>Árvore genealógica</h3><div className="tree"><TreeCard b={ff} label="Avô paterno"/><TreeCard b={fm} label="Avó paterna"/><TreeCard b={mf} label="Avô materno"/><TreeCard b={mm} label="Avó materna"/></div><div className="tree"><TreeCard b={father} label="Pai"/><TreeCard b={mother} label="Mãe"/><div/></div><div className="tree"><TreeCard b={root} label="Ave principal" main/><div/><div/></div></div>
  <div className="card"><h3>Descendentes</h3>{children?.length?<div className="descendant-grid">{children.map((c:any)=><Link key={c.id} className="descendant" href={`/dashboard/plantel/${c.id}`}><strong>{c.name}</strong><small>{c.sex} · {c.ring_number||"sem anilha"}</small></Link>)}</div>:<p>Nenhum descendente cadastrado.</p>}</div></div>
 </main>
}
