import Link from "next/link";
import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { createClient } from "@/lib/supabase/server";
import { Home, Bird, Layers3, CreditCard, Settings, Stethoscope, ShieldCheck, LockKeyhole } from "lucide-react";
import SignOutButton from "@/components/sign-out";
import ExitCreatorPreview from "@/components/exit-creator-preview";
import { hasFeature, normalizePlan } from "@/lib/plans";
import { FEATURES } from "@/lib/features";

const moduleIcon: Record<string,string>={"importacao-anilha":"↥","gestao-anilhas":"◉","gestao-ave":"🐦","galeria-fotos":"▧","gestao-documentos":"▤","gestao-gaiola":"⌂","historico-ave":"◷",comportamento:"◌",genealogia:"⌘",painel:"▦","cartao-gaiola":"▣","imprimir-ficha":"▤","imprimir-plantel":"☷","imprimir-genealogia":"⌘",sms:"✉",reproducao:"♧",doencas:"✚",medicamentos:"✚",genotipagem:"◇",sexagem:"⚥","agendar-veterinario":"♧","consulta-veterinaria-inclusa":"★"};

function CreatorSidebar({plan,ownerPreview}:{plan:string;ownerPreview:boolean}){
 const normalized=normalizePlan(plan); const tierLabel=normalized==='lenda'?'Lenda':normalized==='profissional'?'Profissional':normalized==='amador'?'Amador':'Grátis';
 const links=[['/dashboard','Visão geral',Home],['/dashboard/plantel','Meu plantel',Bird],['/dashboard/recursos','Recursos',Layers3],['/dashboard/especies','Espécies',Bird],['/dashboard/veterinario/agendar','Veterinário',Stethoscope],['/dashboard/assinatura','Assinatura',CreditCard],['/dashboard/configuracoes','Configurações',Settings]] as const;
 const available=FEATURES.filter(f=>hasFeature(normalized,f.code));
 return <aside className="sidebar creator-sidebar"><div className="side-brand"><span className="brand-mark">MC</span><span>Meu Criatório</span></div>{ownerPreview&&<div className="preview-banner"><span>Modo teste</span><strong>{tierLabel}</strong></div>}<nav className="side-nav">{links.map(([href,label,Icon])=><Link key={href} href={href}><Icon size={17}/><span>{label}</span></Link>)}</nav><div className="side-section"><div className="side-section-title">Módulos do plano</div><div className="side-modules">{available.map(f=><Link key={f.code} href={`/dashboard/recursos?modulo=${f.code}`} className="side-module"><span>{moduleIcon[f.code]||'•'}</span><span>{f.title}</span></Link>)}</div>{normalized==='free'&&<div className="side-locked"><LockKeyhole size={14}/><span>Mais recursos são liberados nos planos pagos.</span></div>}</div>{ownerPreview&&<ExitCreatorPreview/>}<SignOutButton/></aside>
}

export default async function DashboardLayout({children}:{children:ReactNode}){
 const supabase=await createClient();const {data:{user}}=await supabase.auth.getUser();if(!user)redirect('/login');const {data:p}=await supabase.from('profiles').select('role,plan,criatorio_name').eq('id',user.id).maybeSingle();
 const ownerEmail=(process.env.OWNER_EMAIL||'gabrielbzago@gmail.com').trim().toLowerCase();const isOwner=(p?.role==='owner')||((user.email||'').trim().toLowerCase()===ownerEmail);const role=isOwner?'owner':(p?.role||'creator');
 if(role==='veterinarian')return <div className="dashboard-shell"><aside className="sidebar"><div className="side-brand"><span className="brand-mark">MV</span><span>Área Veterinária</span></div><nav className="side-nav"><Link href="/dashboard/veterinario"><Stethoscope size={17}/><span>Painel veterinário</span></Link><Link href="/veterinario"><Home size={17}/><span>Página pública</span></Link><SignOutButton/></nav></aside><section className="main-area"><header className="topbar"><b>{p?.criatorio_name||'Veterinário parceiro'}</b><span className="badge">Parceiro</span></header>{children}</section></div>;
 const preview=isOwner&&(await cookies()).get('mc_creator_preview')?.value==='1';
 if(role==='owner'&&!preview)return <div className="dashboard-shell"><aside className="sidebar"><div className="side-brand"><span className="brand-mark">MC</span><span>Owner</span></div><nav className="side-nav"><Link href="/dashboard/owner"><ShieldCheck size={17}/><span>Gestão da plataforma</span></Link><Link href="/"><Home size={17}/><span>Site</span></Link><SignOutButton/></nav></aside><section className="main-area"><header className="topbar"><b>Meu Criatório · Owner</b><span className="badge">Administração</span></header>{children}</section></div>;
 return <div className="dashboard-shell"><CreatorSidebar plan={p?.plan||'free'} ownerPreview={isOwner&&preview}/><section className="main-area"><header className="topbar"><b>{p?.criatorio_name||'Meu Criatório'}</b><div style={{fontSize:12,color:'var(--muted)',display:'flex',gap:10,alignItems:'center'}}><span>{user.email}</span><span className="badge">{normalizePlan(p?.plan)==='lenda'?'Criador Lenda':normalizePlan(p?.plan)==='profissional'?'Profissional':normalizePlan(p?.plan)==='amador'?'Amador':'Grátis'}</span></div></header>{children}</section></div>;
}
