import Link from "next/link";
import { requireUser } from "@/lib/auth";
import { Search } from "lucide-react";
import { normalizePlan } from "@/lib/plans";

export default async function PlantelPage({searchParams}:{searchParams:Promise<{q?:string}>}){
 const {supabase,user}=await requireUser(); const {data:profile}=await supabase.from("profiles").select("plan").eq("id",user.id).maybeSingle(); const paid=normalizePlan(profile?.plan)!=="free"; const q=(await searchParams).q||"";
 let query=supabase.from("birds").select("id,name,sex,status,birth_date,ring_number,genetic_line,species:species_id(common_name,scientific_name),father_id,mother_id").order("created_at",{ascending:false});
 if(q) query=query.ilike("name",`%${q}%`);
 const {data:birds}=await query;
 return <main className="content"><div className="page-title"><div><h1>Meu plantel</h1><p>Todos os registros das suas aves.</p></div><div className="actions" style={{margin:0}}>{paid?<a href="/api/print/plantel" target="_blank" className="btn btn-soft">🖨 Imprimir plantel</a>:<span className="btn btn-soft" title="Disponível nos planos pagos">🔒 Imprimir plantel · plano pago</span>}<Link href="/dashboard/plantel/novo" className="btn btn-primary">+ Nova ave</Link></div></div>
 <form className="toolbar"><Search size={18} color="var(--muted)"/><input name="q" defaultValue={q} placeholder="Buscar por nome..." style={{border:0,outline:0,background:"transparent",flex:1,minWidth:180}}/><button className="btn btn-soft" type="submit">Buscar</button></form>
 <div className="table-card">{birds?.length?<table><thead><tr><th>Ave</th><th>Espécie</th><th>Sexo</th><th>Status</th><th>Anilha</th><th>Genealogia</th></tr></thead><tbody>{birds.map((b:any)=><tr key={b.id}><td><Link href={`/dashboard/plantel/${b.id}`} style={{fontWeight:700,color:"var(--primary-dark)"}}>{b.name}</Link></td><td>{b.species?.common_name||"—"}<br/><small style={{color:"var(--muted)"}}>{b.species?.scientific_name||""}</small></td><td>{b.sex}</td><td><span className="badge">{b.status}</span></td><td>{b.ring_number||"—"}</td><td>{b.father_id||b.mother_id?<span className="badge">Conectada</span>:"—"}</td></tr>)}</tbody></table>:<div className="empty">Nenhuma ave cadastrada ainda.<br/><Link href="/dashboard/plantel/novo" style={{color:"var(--primary-dark)",fontWeight:700}}>Cadastrar primeira ave</Link></div>}</div>
 </main>
}
