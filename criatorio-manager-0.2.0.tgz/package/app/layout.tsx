import "./globals.css";
import type { Metadata } from "next";
import type {ReactNode} from "react";

export const metadata: Metadata = {
  title: "Meu Criatório",
  description: "Gestão de plantel, genealogia e registros para criadores de aves.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
