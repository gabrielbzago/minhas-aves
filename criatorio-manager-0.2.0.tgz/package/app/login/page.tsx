"use client";

import Link from "next/link";
import { FormEvent, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [error,setError]=useState(""); const [loading,setLoading]=useState(false);
  const router=useRouter();
  async function signInWithGoogle(){
    setLoading(true); setError("");
    const supabase=createClient();
    const {error}=await supabase.auth.signInWithOAuth({
      provider:"google",
      options:{redirectTo:`${window.location.origin}/auth/confirm`}
    });
    if(error){setError(error.message);setLoading(false);}
  }
  async function submit(e:FormEvent){e.preventDefault();setLoading(true);setError("");const {error}=await createClient().auth.signInWithPassword({email,password});if(error)setError(error.message);else router.push("/dashboard");setLoading(false);}
  return <main className="auth-page"><div className="auth-card"><Link className="brand" href="/"><span className="brand-mark">AV</span><span>Meu Criatório</span></Link><h1 style={{marginTop:30}}>Entrar</h1><p>Acesse seu plantel e continue de onde parou.</p>{error&&<div className="error">{error}</div>}<form onSubmit={submit}><div className="field"><label>E-mail</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)}/></div><div className="field"><label>Senha</label><input type="password" required minLength={6} value={password} onChange={e=>setPassword(e.target.value)}/></div><button className="btn btn-primary" style={{width:"100%"}} disabled={loading}>{loading?"Entrando...":"Entrar"}</button></form>
<div className="auth-divider"><span>ou</span></div>
<button type="button" className="google-btn" onClick={signInWithGoogle} disabled={loading}>
  <span className="google-icon">G</span><span>Continuar com Google</span>
</button>
<p style={{fontSize:13,marginTop:20}}>Ainda não tem conta? <Link href="/cadastro" style={{color:"var(--primary-dark)",fontWeight:700}}>Criar conta</Link></p></div></main>
}
