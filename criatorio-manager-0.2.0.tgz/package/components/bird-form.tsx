"use client";
import {useState} from "react"; import {useRouter} from "next/navigation"; import {createClient} from "@/lib/supabase/client";

export default function BirdForm({species,birds,initialBird}:{species:any[],birds:any[],initialBird?:any}) {
 const router=useRouter(); const [loading,setLoading]=useState(false);const [error,setError]=useState("");
 const [f,setF]=useState<any>(initialBird?{...initialBird,genetics:initialBird.genetics?Object.entries(initialBird.genetics).map(([a,b])=>`${a}:${b}`).join(","):"",species_id:initialBird.species_id||"",father_id:initialBird.father_id||"",mother_id:initialBird.mother_id||""}:{name:"",species_id:"",sex:"indeterminado",birth_date:"",death_date:"",transfer_date:"",status:"ativo",ring_number:"",ibama_registration_number:"",ibama_record_type:"",father_id:"",mother_id:"",genetic_line:"",genetics:"",breeder_matrix:false,notes:""});
 const set=(k:string,v:any)=>setF((x:any)=>({...x,[k]:v}));
 async function submit(e:any){
  e.preventDefault();
  setLoading(true);
  setError("");

  // Campos date do Postgres aceitam NULL, mas não aceitam string vazia ("" ).
  // O input type=date devolve "" quando o usuário não preenche a data.
  // Normalizamos todos os campos opcionais antes de enviar ao Supabase.
  const nullableDate=(value:any)=>value && String(value).trim() ? value : null;
  const cleanText=(value:any)=>value && String(value).trim() ? String(value).trim() : null;
  const genetics=f.genetics && String(f.genetics).trim()
    ? Object.fromEntries(String(f.genetics).split(",").map((x:string)=>{
        const [a,b]=x.split(":");
        return [a?.trim(),b?.trim()];
      }).filter(([a,b])=>a && b))
    : null;

  const payload={
    ...f,
    birth_date:nullableDate(f.birth_date),
    death_date:nullableDate(f.death_date),
    transfer_date:nullableDate(f.transfer_date),
    species_id:cleanText(f.species_id),
    father_id:cleanText(f.father_id),
    mother_id:cleanText(f.mother_id),
    ring_number:cleanText(f.ring_number),
    ibama_registration_number:cleanText(f.ibama_registration_number),
    ibama_record_type:cleanText(f.ibama_record_type),
    genetic_line:cleanText(f.genetic_line),
    genetics,
    notes:cleanText(f.notes),
  };

  const {error}=initialBird
    ? await createClient().from("birds").update(payload).eq("id",initialBird.id)
    : await createClient().from("birds").insert(payload);

  if(error) setError(error.message);
  else router.push(initialBird?`/dashboard/plantel/${initialBird.id}`:"/dashboard/plantel");
  setLoading(false);
}
 return <form className="form-card" onSubmit={submit}>{error&&<div className="error">{error}</div>}<div className="form-grid">
 <div className="field"><label>Nome da ave *</label><input required value={f.name} onChange={e=>set("name",e.target.value)} placeholder="Ex.: Thor"/></div>
 <div className="field"><label>Espécie *</label><select required value={f.species_id} onChange={e=>set("species_id",e.target.value)}><option value="">Selecione...</option>{species.map(s=><option key={s.id} value={s.id}>{s.common_name} — {s.scientific_name}</option>)}</select></div>
 <div className="field"><label>Sexagem / sexo</label><select value={f.sex} onChange={e=>set("sex",e.target.value)}><option value="macho">Macho</option><option value="femea">Fêmea</option><option value="indeterminado">Indeterminado</option></select></div>
 <div className="field"><label>Status</label><select value={f.status} onChange={e=>set("status",e.target.value)}><option value="ativo">Ativo</option><option value="falecido">Falecido</option><option value="transferido">Transferido</option><option value="arquivado">Arquivado</option></select></div>
 <div className="field"><label>Data de nascimento</label><input type="date" value={f.birth_date||""} onChange={e=>set("birth_date",e.target.value)}/></div>
 <div className="field"><label>Data de falecimento</label><input type="date" value={f.death_date||""} onChange={e=>set("death_date",e.target.value)}/></div>
 <div className="field"><label>Data de transferência</label><input type="date" value={f.transfer_date||""} onChange={e=>set("transfer_date",e.target.value)}/></div>
 <div className="field"><label>Número da anilha</label><input value={f.ring_number} onChange={e=>set("ring_number",e.target.value)} placeholder="Número / identificação"/></div>
 <div className="field"><label>Registro regulatório (informado pelo criador)</label><input value={f.ibama_registration_number} onChange={e=>set("ibama_registration_number",e.target.value)} placeholder="Preencha conforme seu documento"/></div>
 <div className="field"><label>Tipo do registro</label><input value={f.ibama_record_type} onChange={e=>set("ibama_record_type",e.target.value)} placeholder="Ex.: registro, licença, origem"/></div>
 <div className="field"><label>Pai</label><select value={f.father_id} onChange={e=>set("father_id",e.target.value)}><option value="">Não informado</option>{birds.filter(b=>b.sex==="macho").map(b=><option key={b.id} value={b.id}>{b.name} — {b.ring_number||"sem anilha"}</option>)}</select></div>
 <div className="field"><label>Mãe</label><select value={f.mother_id} onChange={e=>set("mother_id",e.target.value)}><option value="">Não informado</option>{birds.filter(b=>b.sex==="femea").map(b=><option key={b.id} value={b.id}>{b.name} — {b.ring_number||"sem anilha"}</option>)}</select></div>
 <div className="field"><label>Linhagem / genética</label><input value={f.genetic_line} onChange={e=>set("genetic_line",e.target.value)} placeholder="Ex.: linha X, mutação Y"/></div>
 <div className="field"><label>Genotipagem / genética detalhada</label><input value={f.genetics} onChange={e=>set("genetics",e.target.value)} placeholder="Ex.: mutação:opalino, portador:ino"/></div>
 <div className="field full"><label><input type="checkbox" checked={f.breeder_matrix} onChange={e=>set("breeder_matrix",e.target.checked)} style={{width:"auto",marginRight:8}}/> Marcar como matriz principal do criatório</label></div>
 <div className="field full"><label>Observações</label><textarea rows={5} value={f.notes} onChange={e=>set("notes",e.target.value)} placeholder="Informações adicionais, origem, características, histórico..."/></div>
 </div><div className="form-actions"><button type="button" className="btn btn-ghost" onClick={()=>router.back()}>Cancelar</button><button className="btn btn-primary" disabled={loading}>{loading?"Salvando...":(initialBird?"Salvar alterações":"Salvar ave")}</button></div></form>
}
