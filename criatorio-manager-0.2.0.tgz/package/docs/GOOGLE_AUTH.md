# Google Auth — configuração

O projeto já contém o botão **Continuar com Google** no login e **Cadastrar com Google** no cadastro.

## 1. Google Cloud

Crie/seleciona um projeto no Google Cloud Console e configure a tela de consentimento OAuth.

Crie um OAuth Client ID do tipo **Web application**.

No campo de URI de redirecionamento autorizado, use o callback exibido no Supabase:

`https://SEU-PROJETO.supabase.co/auth/v1/callback`

Não coloque o Client Secret no código do projeto.

## 2. Supabase

Abra:

`Authentication → Providers → Google`

Habilite o Google e informe:

- Client ID
- Client Secret

Depois confira em:

`Authentication → URL Configuration`

As URLs de redirecionamento da aplicação devem permitir:

`http://localhost:3000/auth/confirm`

e a URL equivalente de produção.

O código do projeto usa:

`/auth/confirm`

para trocar o authorization code por uma sessão segura do Supabase.

## 3. Fluxo

1. Usuário clica em Google.
2. Supabase redireciona para o Google.
3. Google autentica o usuário.
4. Google retorna ao callback do Supabase.
5. Supabase retorna para `/auth/confirm`.
6. A aplicação troca o código por sessão.
7. O usuário entra no `/dashboard`.

As credenciais do Google não ficam armazenadas no frontend.

## 4. Cadastro com Google

O Google não fornece o nome do criatório no fluxo padrão. Portanto, depois do primeiro acesso, o usuário deve preencher o nome/logo do criatório em **Configurações**.

O trigger existente de `profiles` continua criando o perfil do usuário automaticamente.
