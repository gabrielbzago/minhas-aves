export const PLAN_INFO = {
  free: { label: "Grátis", maxBirds: 5, annualPrice: 0 },
  amador: { label: "Criatório Amador", maxBirds: null, annualPrice: 149.90 },
  profissional: { label: "Criatório Profissional", maxBirds: null, annualPrice: 249.90 },
  lenda: { label: "Criador Lenda", maxBirds: null, annualPrice: 349.90 },
} as const;

export type PlanCode = keyof typeof PLAN_INFO;

const commonPaid = [
  "importacao-anilha", "gestao-anilhas", "gestao-ave", "galeria-fotos", "gestao-documentos",
  "gestao-gaiola", "historico-ave", "comportamento", "genealogia", "painel", "cartao-gaiola", "imprimir-ficha", "imprimir-plantel", "imprimir-genealogia",
];

export const PLAN_FEATURES: Record<PlanCode, Set<string>> = {
  free: new Set(["gestao-ave", "historico-ave", "genealogia", "painel", "especies", "cartao-gaiola", "agendar-veterinario"]),
  amador: new Set([...commonPaid, "agendar-veterinario"]),
  profissional: new Set([...commonPaid, "sms", "reproducao", "doencas", "medicamentos", "genotipagem", "sexagem", "agendar-veterinario"]),
  lenda: new Set([...commonPaid, "sms", "reproducao", "doencas", "medicamentos", "genotipagem", "sexagem", "agendar-veterinario", "consulta-veterinaria-inclusa"]),
};

export function normalizePlan(plan?: string | null): PlanCode {
  if (plan === "amador" || plan === "profissional" || plan === "lenda") return plan;
  return "free";
}

export function hasFeature(plan: string | null | undefined, feature: string) {
  return PLAN_FEATURES[normalizePlan(plan)].has(feature);
}
